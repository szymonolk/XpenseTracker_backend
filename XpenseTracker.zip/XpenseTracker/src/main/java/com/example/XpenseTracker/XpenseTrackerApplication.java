package com.example.XpenseTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XpenseTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(XpenseTrackerApplication.class, args);
	}

}
