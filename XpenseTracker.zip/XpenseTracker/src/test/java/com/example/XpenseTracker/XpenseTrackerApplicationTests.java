package com.example.XpenseTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XpenseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
